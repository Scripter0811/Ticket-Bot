/*
Ticket-Bot is licensed under the GNU Affero General Public License,
version 3 only ("AGPL-3.0-only"). See LICENSE.md for the full license text.

Additional Term under GNU AGPL v3, Section 7(b):

You are required to preserve and display, in a location clearly visible
to end users interacting with the bot (such as bot embeds, the bot's
"Bio" Discord profile, status, or equivalent), a notice that the
software is powered by Ticket-Bot, including a link to the original
project repository or to its website.

This notice must not be removed, obscured, or replaced.
*/

import { API } from "@discordjs/core";
import { REST } from "@discordjs/rest";
import type { RESTPostAPIChatInputApplicationCommandsJSONBody } from "discord-api-types/v10";
import { config } from "dotenv";
import { discoverCommands, discoverEvents, discoverFeatures } from "@/core/discovery";
import { createBotI18n } from "@/core/i18n";
import { createLogger, type Logger } from "@/core/logger";
import { createHandlerRegistry } from "@/core/registry";
import botConfig from "../config/config.js";

config({ path: "./config/.env", quiet: true });
const logger = createLogger("deploy");

export async function deployApplicationCommands(options: {
	applicationCommands: RESTPostAPIChatInputApplicationCommandsJSONBody[];
	clientId: string;
	guildId?: string;
	logger: Logger;
	token: string;
}) {
	const rest = new REST({ version: "10" }).setToken(options.token);
	const api = new API(rest);

	if (options.guildId) {
		await api.applicationCommands.bulkOverwriteGuildCommands(options.clientId, options.guildId, options.applicationCommands);

		options.logger.info(`Deployed ${options.applicationCommands.length} guild commands to ${options.guildId}.`);
		return;
	}

	await api.applicationCommands.bulkOverwriteGlobalCommands(options.clientId, options.applicationCommands);

	options.logger.info(`Deployed ${options.applicationCommands.length} global commands.`);
}

export async function deployCommands() {
	const [commands, events, features] = await Promise.all([
		discoverCommands(logger),
		discoverEvents(logger),
		discoverFeatures(logger)
	]);
	const i18n = createBotI18n(botConfig.lang, logger);
	const registry = createHandlerRegistry({ commands, features, events, logger, LL: i18n.LL });

	await deployApplicationCommands({
		applicationCommands: registry.applicationCommands,
		clientId: botConfig.clientId,
		guildId: botConfig.guildId,
		logger,
		token: process.env.DISCORD_TOKEN
	});
}

/*
Ticket-Bot is licensed under the GNU Affero General Public License,
version 3 only ("AGPL-3.0-only"). See LICENSE.md for the full license text.

Additional Term under GNU AGPL v3, Section 7(b):

You are required to preserve and display, in a location clearly visible
to end users interacting with the bot (such as bot embeds, the bot's
"Bio" Discord profile, status, or equivalent), a notice that the
software is powered by Ticket-Bot, including a link to the original
project repository or to its website.

This notice must not be removed, obscured, or replaced.
*/
